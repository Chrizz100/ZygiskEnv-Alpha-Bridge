#ifndef LOGGER_H
#define LOGGER_H
#include <android/log.h>

#define LOG_TAG "ZygiskEnvBridge"
#ifdef DEBUG
# define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#else
# define LOGD(...) ((void)0)
#endif
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

#endif
