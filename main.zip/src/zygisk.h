#ifndef ZYGISK_H
#define ZYGISK_H

#include <stdbool.h>
#include <stdint.h>
#include <sys/types.h>
#include <jni.h>

/* ABI-compatible with Zygisk API v5 and ReZygisk v1.0.0. */
struct AppSpecializeArgs {
    jint *uid;
    jint *gid;
    jintArray *gids;
    jint *runtime_flags;
    jobjectArray *rlimits;
    jint *mount_external;
    jstring *se_info;
    jstring *nice_name;
    jstring *instruction_set;
    jstring *app_data_dir;
    jintArray *fds_to_ignore;
    jboolean *is_child_zygote;
    jboolean *is_top_app;
    jobjectArray *pkg_data_info_list;
    jobjectArray *whitelisted_data_info_list;
    jboolean *mount_data_dirs;
    jboolean *mount_storage_dirs;
    jboolean *mount_sysprop_overrides;
};

struct ServerSpecializeArgs {
    jint *uid;
    jint *gid;
    jintArray *gids;
    jint *runtime_flags;
    jlong *permitted_capabilities;
    jlong *effective_capabilities;
};

enum zygisk_options {
    FORCE_DENYLIST_UNMOUNT = 0,
    DLCLOSE_MODULE_LIBRARY = 1
};

enum {
    PROCESS_GRANTED_ROOT = (1U << 0),
    PROCESS_ON_DENYLIST = (1U << 1),
    /* ReZygisk specific: official Magisk masks its private manager flag. */
    PROCESS_IS_MANAGER = (1U << 27),
    PROCESS_ROOT_IS_APATCH = (1U << 28),
    PROCESS_ROOT_IS_KSU = (1U << 29),
    PROCESS_ROOT_IS_MAGISK = (1U << 30)
};

struct module_abi {
    long api_version;
    void *impl;
    void (*preAppSpecialize)(void *, struct AppSpecializeArgs *);
    void (*postAppSpecialize)(void *, const struct AppSpecializeArgs *);
    void (*preServerSpecialize)(void *, struct ServerSpecializeArgs *);
    void (*postServerSpecialize)(void *, const struct ServerSpecializeArgs *);
};

struct api_table {
    void *impl;
    bool (*registerModule)(struct api_table *, struct module_abi *);
    void (*hookJniNativeMethods)(JNIEnv *, const char *, JNINativeMethod *, int);
    void (*pltHookRegister)(dev_t, ino_t, const char *, void *, void **);
    bool (*exemptFd)(int);
    bool (*pltHookCommit)(void);
    int (*connectCompanion)(void *);
    void (*setOption)(void *, enum zygisk_options);
    int (*getModuleDir)(void *);
    uint32_t (*getFlags)(void *);
};

__attribute__((visibility("default"))) void zygisk_module_entry(struct api_table *, JNIEnv *);
__attribute__((visibility("default"))) void zygisk_companion_entry(int);

#endif
