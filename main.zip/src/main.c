/*
 * ZygiskEnv Alpha Bridge - compatibility shim for ReZygisk and Magisk Alpha.
 * Based on TheSillyOk/ZygiskEnv (Unlicense); see README.md.
 *
 * This shim cannot change Magisk's daemon-side Zygisk configuration or
 * restore upstream support. It only conveys the runtime marker to a manager
 * process after Android has completed specializing it.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "zygisk.h"
#include "logger.h"

static struct api_table *zygisk_api;
static JNIEnv *jni_env;

/* Exact package match or an Android :subprocess; no loose substring matching. */
static bool is_package_process(const char *process, const char *package) {
    if (!process || !package) return false;
    size_t n = strlen(package);
    return strncmp(process, package, n) == 0 &&
           (process[n] == '\0' || process[n] == ':');
}

static bool known_magisk_manager(const char *process) {
    return is_package_process(process, "com.topjohnwu.magisk") ||
           is_package_process(process, "io.github.vvb2060.magisk");
}

static bool should_set_runtime_marker(uint32_t flags, const char *process) {
    /* Trust ReZygisk's root-manager detection first (including KSU/APatch). */
    if ((flags & PROCESS_IS_MANAGER) != 0U) return true;

    /* Fallback for Magisk Alpha's package even if ReZygisk doesn't detect its
       manager UID. We never set the marker for unrelated root-granted apps. */
    if ((flags & PROCESS_ROOT_IS_MAGISK) != 0U)
        return known_magisk_manager(process);

    /* Preserve the original KernelSU Next manager fallback. */
    if ((flags & PROCESS_ROOT_IS_KSU) != 0U)
        return is_package_process(process, "com.rifsxd.ksunext");

    return false;
}

static void pre_app_specialize(void *data, struct AppSpecializeArgs *args) {
    (void)data;
    (void)args;
    if (zygisk_api && zygisk_api->setOption)
        zygisk_api->setOption(zygisk_api->impl, DLCLOSE_MODULE_LIBRARY);
}

static void post_app_specialize(void *data, const struct AppSpecializeArgs *args) {
    (void)data;
    if (!zygisk_api || !zygisk_api->getFlags || !jni_env || !args ||
        !args->nice_name || !*args->nice_name) return;

    /* Execute only for a supported root-manager process, never globally.
       Magisk's built-in Zygisk must remain disabled when using ReZygisk. */
    uint32_t flags = zygisk_api->getFlags(zygisk_api->impl);

    const char *process = (*jni_env)->GetStringUTFChars(jni_env, *args->nice_name, NULL);
    if (!process) {
        LOGW("JNI name lookup failed; skipping runtime marker");
        return;
    }

    bool set_marker = should_set_runtime_marker(flags, process);
    if (set_marker) {
        if (setenv("ZYGISK_ENABLED", "1", 1) != 0)
            LOGW("Failed to set runtime marker for %s", process);
        else
            LOGI("Set runtime marker post-specialize for %s (flags=0x%08x)", process, flags);
    } else {
        LOGD("Unrelated process skipped: %s", process);
    }

    (*jni_env)->ReleaseStringUTFChars(jni_env, *args->nice_name, process);
}

static void pre_server_specialize(void *data, struct ServerSpecializeArgs *args) {
    (void)data;
    (void)args;
    if (zygisk_api && zygisk_api->setOption)
        zygisk_api->setOption(zygisk_api->impl, DLCLOSE_MODULE_LIBRARY);
}

static void post_server_specialize(void *data, const struct ServerSpecializeArgs *args) {
    (void)data;
    (void)args;
}

void zygisk_module_entry(struct api_table *table, JNIEnv *env) {
    if (!table || !table->registerModule || !env) return;
    zygisk_api = table;
    jni_env = env;

    static struct module_abi abi = {
        .api_version = 5,
        .impl = (void *)"zygisk_env",
        .preAppSpecialize = pre_app_specialize,
        .postAppSpecialize = post_app_specialize,
        .preServerSpecialize = pre_server_specialize,
        .postServerSpecialize = post_server_specialize
    };
    (void)table->registerModule(table, &abi);
}

void zygisk_companion_entry(int fd) {
    (void)fd;
}

#ifdef ZYGISK_ENV_TEST
/* Narrow test accessor for host-side logic tests. Not compiled in release. */
int zygisk_env_test_should_set(uint32_t flags, const char *process) {
    return should_set_runtime_marker(flags, process) ? 1 : 0;
}
#endif
