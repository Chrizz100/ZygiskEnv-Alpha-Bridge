#ifndef ANDROID_LOG_H
#define ANDROID_LOG_H
#define ANDROID_LOG_DEBUG 3
#define ANDROID_LOG_INFO 4
#define ANDROID_LOG_WARN 5
static inline int __android_log_print(int priority, const char *tag, const char *fmt, ...) {
    (void)priority; (void)tag; (void)fmt;
    return 0;
}
#endif
