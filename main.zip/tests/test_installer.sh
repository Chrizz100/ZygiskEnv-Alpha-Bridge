#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
TEMP=$(mktemp -d)
trap 'rm -rf "$TEMP"' EXIT HUP INT TERM

# Test shell's installer entry with mock Magisk functions, no root required.
cp -R "$ROOT/module/." "$TEMP/"
mkdir -p "$TEMP/zygisk"
for a in arm64-v8a armeabi-v7a x86 x86_64; do : > "$TEMP/zygisk/$a.so"; done

# Encapsulate in subshell to prevent abort from ending the test script.
run_case() (
  ARCH=$1; ABIS=$2; EXPECT=$3; MODPATH=$TEMP; TMPDIR=$TEMP
  export ARCH MODPATH TMPDIR
  grep_prop() { sed -n "s/^$1=//p" "$2"; }
  ui_print() { :; }
  abort() { printf '%s\n' "$1" >&2; exit 1; }
  getprop() { printf '%s\n' "$ABIS"; }
  . "$ROOT/module/customize.sh"
  for a in arm64-v8a armeabi-v7a x86 x86_64; do
    case "$EXPECT" in
      *"[$a]"*) [ -f "$MODPATH/zygisk/$a.so" ] || exit 1 ;;
      *) [ ! -f "$MODPATH/zygisk/$a.so" ] || exit 1 ;;
    esac
  done
)

run_case arm64 'arm64-v8a,armeabi-v7a,armeabi' '[arm64-v8a][armeabi-v7a]'
# Restore removed files for 32-bit-only test
for a in arm64-v8a armeabi-v7a x86 x86_64; do : > "$TEMP/zygisk/$a.so"; done
run_case arm 'armeabi-v7a,armeabi' '[armeabi-v7a]'
for a in arm64-v8a armeabi-v7a x86 x86_64; do : > "$TEMP/zygisk/$a.so"; done
run_case x64 'x86_64,x86' '[x86_64][x86]'
for a in arm64-v8a armeabi-v7a x86 x86_64; do : > "$TEMP/zygisk/$a.so"; done
run_case x86 'x86' '[x86]'
printf 'PASS: arm, arm64, x86, x86_64 installer architecture cases\n'
