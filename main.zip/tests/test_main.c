#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "zygisk.h"

extern int zygisk_env_test_should_set(uint32_t flags, const char *process);

static struct module_abi *registered;
static uint32_t process_flags;
static int set_option_calls;

static bool register_module(struct api_table *api, struct module_abi *abi) {
    (void)api;
    registered = abi;
    return true;
}
static uint32_t read_flags(void *impl) {
    (void)impl;
    return process_flags;
}
static void set_option(void *impl, enum zygisk_options opt) {
    (void)impl;
    assert(opt == DLCLOSE_MODULE_LIBRARY);
    set_option_calls++;
}
static const char *jni_get_string(JNIEnv *env, jstring str, jboolean *copy) {
    (void)env; (void)copy;
    return (const char *)str;
}
static void jni_release_string(JNIEnv *env, jstring str, const char *chars) {
    (void)env; (void)str; (void)chars;
}
static const struct JNINativeInterface_ funcs = {
    .GetStringUTFChars = jni_get_string,
    .ReleaseStringUTFChars = jni_release_string
};

static void check(uint32_t flags, const char *process, bool expected) {
    unsetenv("ZYGISK_ENABLED");
    process_flags = flags;
    jstring jprocess = (jstring)process;
    struct AppSpecializeArgs args = {.nice_name = &jprocess};
    registered->preAppSpecialize(registered->impl, &args);
    assert(getenv("ZYGISK_ENABLED") == NULL);  /* not in pre-stage */
    registered->postAppSpecialize(registered->impl, &args);
    const char *marker = getenv("ZYGISK_ENABLED");
    assert(((marker != NULL) && strcmp(marker, "1") == 0) == expected);
    assert(zygisk_env_test_should_set(flags, process) == (int)expected);
}

int main(void) {
    JNIEnv env = &funcs;
    struct api_table api = {
        .registerModule = register_module,
        .getFlags = read_flags,
        .setOption = set_option
    };
    zygisk_module_entry(&api, &env);
    assert(registered != NULL && registered->api_version == 5);
    check(PROCESS_ROOT_IS_MAGISK | PROCESS_IS_MANAGER, "random.manager", true);
    check(PROCESS_ROOT_IS_MAGISK, "io.github.vvb2060.magisk", true);
    check(PROCESS_ROOT_IS_MAGISK, "com.topjohnwu.magisk:remote", true);
    check(PROCESS_ROOT_IS_MAGISK, "io.github.vvb2060.magisk:remote", true);
    check(PROCESS_ROOT_IS_MAGISK | PROCESS_GRANTED_ROOT, "com.example.other", false);
    check(PROCESS_ROOT_IS_MAGISK | PROCESS_ON_DENYLIST, "com.other", false);
    check(PROCESS_ROOT_IS_KSU | PROCESS_IS_MANAGER, "com.rifsxd.ksunext", true);
    check(PROCESS_ROOT_IS_MAGISK, "io.github.vvb2060.magisk.evil", false);
    check(0, "io.github.vvb2060.magisk", false);
    check(PROCESS_ROOT_IS_MAGISK, NULL, false);
    check(PROCESS_ROOT_IS_KSU, "com.rifsxd.ksunext", true);
    check(PROCESS_ROOT_IS_KSU | PROCESS_GRANTED_ROOT, "com.example.other", false);
    check(PROCESS_ROOT_IS_APATCH | PROCESS_IS_MANAGER, "random.manager", true);
    check(PROCESS_ROOT_IS_APATCH, "com.example.other", false);
    assert(set_option_calls == 14);
    printf("PASS: 14 manager, root and timing tests; lifecycle callbacks verified\n");
    return 0;
}
