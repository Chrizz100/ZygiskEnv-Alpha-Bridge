#!/system/bin/sh
# Read-only diagnostics. Does not change a boot setting or write to /data/adb.
MODDIR=${0%/*}
REZYGISK=/data/adb/modules/rezygisk
printf '\n--- ZygiskEnv Alpha Bridge diagnostics ---\n'
if command -v magisk >/dev/null 2>&1; then
  printf 'Magisk binary: ' ; magisk -v 2>/dev/null || echo 'unknown'
else
  echo 'Magisk binary: NOT FOUND'
fi
if [ ! -d "$REZYGISK" ]; then
  echo 'ReZygisk: NOT INSTALLED'
elif [ -f "$REZYGISK/disable" ]; then
  echo 'ReZygisk: DISABLED'
else
  echo 'ReZygisk: installed and not disabled'
  if [ -f "$REZYGISK/module.prop" ]; then
    grep '^description=' "$REZYGISK/module.prop" 2>/dev/null || true
  fi
fi
if command -v pidof >/dev/null 2>&1; then
  if pidof zygisk-ptrace64 >/dev/null 2>&1 || pidof zygisk-ptrace32 >/dev/null 2>&1; then
    echo 'ReZygisk monitor process: present (not proof of injection)'
  else
    echo 'ReZygisk monitor process: not found'
  fi
fi
if [ -f "$MODDIR/disable" ]; then
  echo 'Bridge module: DISABLED'
else
  echo 'Bridge module: installed; runtime loading NOT independently verified'
fi
printf '\nTo view runtime-marker entries:\n'
echo 'su -c "logcat -d -s ZygiskEnvBridge:I"'
echo 'These diagnostics DO NOT change Magisk Alpha UI status.'
