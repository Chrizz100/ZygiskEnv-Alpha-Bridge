#!/system/bin/sh
# Magisk/KernelSU module installer; auto-extracted files in $MODPATH.

NAME=$(grep_prop name "$TMPDIR/module.prop")
VERSION=$(grep_prop version "$TMPDIR/module.prop")
ui_print "- Installing $NAME ($VERSION)"

case "$ARCH" in
  arm|arm64) ARCH_TYPE=arm ;;
  x86|x64)   ARCH_TYPE=x86 ;;
  *) abort "! Unsupported architecture: $ARCH" ;;
esac

if [ "${ZYGISK_ENABLED:-}" = 1 ]; then
  abort "! Turn OFF Magisk built-in Zygisk and reboot before using ReZygisk"
fi

if [ ! -d /data/adb/modules/rezygisk ] && [ ! -d /data/adb/modules_update/rezygisk ]; then
  ui_print "! ReZygisk not detected; install it separately before rebooting"
fi

ABI_1=$(getprop ro.system.product.cpu.abilist)
ABI_2=$(getprop ro.product.cpu.abilist)
if [ "${#ABI_2}" -gt "${#ABI_1}" ]; then
  CPU_ABIS=$ABI_2
else
  CPU_ABIS=$ABI_1
fi

HAS_32=false
HAS_64=false
case "$CPU_ABIS" in
  *arm64-v8a*|*x86_64*) HAS_64=true ;;
esac
case ",$CPU_ABIS," in
  *,armeabi-v7a,*|*,armeabi,*|*,x86,*) HAS_32=true ;;
esac

# Some ROMs don't report a useful abilist: fall back to installed architecture.
if [ -z "$CPU_ABIS" ]; then
  case "$ARCH" in
    arm|x86) HAS_32=true ;;
    arm64|x64) HAS_64=true ;;
  esac
fi

if [ "$HAS_32" != true ] && [ "$HAS_64" != true ]; then
  abort "! Could not determine supported ABIs: $CPU_ABIS"
fi

rm_if_unneeded() {
  FILE="$1"; REQUIRED_ARCH="$2"; REQUIRED_BITS="$3"
  if [ "$ARCH_TYPE" != "$REQUIRED_ARCH" ] || \
     { [ "$REQUIRED_BITS" = 32 ] && [ "$HAS_32" != true ]; } || \
     { [ "$REQUIRED_BITS" = 64 ] && [ "$HAS_64" != true ]; }; then
    rm -f "$MODPATH/$FILE"
  else
    [ -f "$MODPATH/$FILE" ] || abort "! Missing Zygisk library: $FILE"
    ui_print "- Keep $FILE"
  fi
}

rm_if_unneeded zygisk/arm64-v8a.so arm 64
rm_if_unneeded zygisk/armeabi-v7a.so arm 32
rm_if_unneeded zygisk/x86_64.so x86 64
rm_if_unneeded zygisk/x86.so x86 32

ui_print "- Runtime marker is set only for detected Magisk manager processes"
ui_print "- Magisk Alpha support remains experimental"
